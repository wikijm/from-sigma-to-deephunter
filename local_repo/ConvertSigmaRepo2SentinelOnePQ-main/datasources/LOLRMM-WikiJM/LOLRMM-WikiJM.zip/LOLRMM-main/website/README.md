# LOLRMM.io

This website uses [Nextra](https://nextra.site) and [Elastic UI](https://eui.elastic.co).

## Local Development

First, run `npm install` to install the dependencies.

Then, run `npm run dev` to start the development server and visit localhost:3000.
